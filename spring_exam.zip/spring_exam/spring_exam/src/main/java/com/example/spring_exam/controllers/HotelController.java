package com.example.spring_exam.controllers;


import com.example.spring_exam.models.Room;
import com.example.spring_exam.models.Reservation;
import com.example.spring_exam.services.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/hotel")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    @GetMapping("/available-rooms")
    public String getAvailableRooms(Model model) {
        List<Room> rooms = hotelService.getAvailableRooms();
        model.addAttribute("rooms", rooms);
        return "available-rooms";
    }

    @PostMapping("/check-in")
    public String checkInClient(@RequestParam Long clientId, @RequestParam Long roomId) {
        hotelService.checkInClient(clientId, roomId);
        return "redirect:/hotel/available-rooms";
    }

    @PostMapping("/check-out")
    public String checkOutClient(@RequestParam Long clientId, @RequestParam Long roomId) {
        hotelService.checkOutClient(clientId, roomId);
        return "redirect:/hotel/occupied-rooms";
    }

    @GetMapping("/occupied-rooms")
    public String getOccupiedRooms(Model model) {
        List<Reservation> reservations = hotelService.getOccupiedRooms();
        model.addAttribute("reservations", reservations);
        return "occupied-rooms";
    }

    @PostMapping("/extend-stay")
    public String extendStay(@RequestParam Long reservationId, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date newCheckOutDate) {
        hotelService.extendStay(reservationId, newCheckOutDate);
        return "redirect:/hotel/occupied-rooms";
    }
}