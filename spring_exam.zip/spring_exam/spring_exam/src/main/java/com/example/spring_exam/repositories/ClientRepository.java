package com.example.spring_exam.repositories;


import com.example.spring_exam.models.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client, Long> {
}