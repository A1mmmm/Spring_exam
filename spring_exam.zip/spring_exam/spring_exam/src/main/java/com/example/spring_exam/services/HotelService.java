package com.example.spring_exam.services;

import com.example.spring_exam.models.Client;
import com.example.spring_exam.models.Reservation;
import com.example.spring_exam.models.Room;
import com.example.spring_exam.repositories.ClientRepository;
import com.example.spring_exam.repositories.ReservationRepository;
import com.example.spring_exam.repositories.RoomRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class HotelService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    // Получение списка свободных комнат
    public List<Room> getAvailableRooms() {
        return roomRepository.findByStatus("свободна");
    }

    // Заселение клиента в комнату
    public void checkInClient(Long clientId, Long roomId) {
        Client client = clientRepository.findById(clientId).orElseThrow(() -> new RuntimeException("Client not found"));
        Room room = roomRepository.findById(roomId).orElseThrow(() -> new RuntimeException("Room not found"));

        if (room.getStatus().equals("свободна")) {
            Reservation reservation = new Reservation();
            reservation.setClient(client);
            reservation.setRoom(room);
            reservation.setCheckInDate(new Date());
            reservation.setCheckOutDate(null);

            // Обновляем статус комнаты на "занята"
            room.setStatus("занята");

            reservationRepository.save(reservation);
            roomRepository.save(room);
        } else {
            throw new RuntimeException("Room is already occupied.");
        }
    }

    // Выселение клиента
    public void checkOutClient(Long clientId, Long roomId) {
        List<Reservation> reservations = reservationRepository.findByRoomId(roomId);

        for (Reservation reservation : reservations) {
            if (reservation.getClient().getId().equals(clientId)) {
                reservation.setCheckOutDate(new Date());
                reservationRepository.save(reservation);

                // Освобождаем комнату
                Room room = reservation.getRoom();
                room.setStatus("свободна");
                roomRepository.save(room);

                break;
            }
        }
    }

    // Получение списка заселенных клиентов
    public List<Reservation> getOccupiedRooms() {
        return reservationRepository.findAll();
    }

    // Продление пребывания
    public void extendStay(Long reservationId, Date newCheckOutDate) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));
        reservation.setCheckOutDate(newCheckOutDate);
        reservationRepository.save(reservation);
    }
}